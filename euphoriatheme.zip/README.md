# Euphoria-Theme
Euphoria Theme Source Code

## Maintenance Mode

This theme includes a "Maintenance Mode" toggle in the Theme Customiser (Admin -> Theme Customiser). When enabled, non-admin visitors who request the site root (`/`) or a server page (`/server/{uuid}`) will see a maintenance page with a button that redirects to the admin area.

The toggle is persisted via the theme's settings under the key `maintenance_enabled`.
